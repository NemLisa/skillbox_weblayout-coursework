import React from "react";
import SimpleBar from "simplebar-react";

const Index = () => (
  <SimpleBar>
    <p>Hello Next.js</p>
  </SimpleBar>
);

export default Index;
