import { NgModule } from '@angular/core';
import { SimplebarAngularComponent } from './simplebar-angular.component';

@NgModule({
  declarations: [SimplebarAngularComponent],
  imports: [],
  exports: [SimplebarAngularComponent]
})
export class SimplebarAngularModule {}
